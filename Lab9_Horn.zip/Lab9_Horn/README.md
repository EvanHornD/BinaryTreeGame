
I wasnt able to finish this before the deadline

sorry about that, it took me longer to bug fix than I thought it would