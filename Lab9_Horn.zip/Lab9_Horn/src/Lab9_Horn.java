import game.Application;

public class Lab9_Horn {
    public static void main(String[] args) throws Exception {
        
        Application game = new Application();
        game.run();
    }
}
